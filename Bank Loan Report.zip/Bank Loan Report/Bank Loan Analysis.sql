USE Bank_Loan_DB

SELECT * FROM Bank_loan_Data


--Problem Statement: We need to summarize important metrics, including total loan applications, 
--total funded amount, total amount received, and averages such as interest rates and Debt-to-Income ratio (DTI).

--Total Loan Applications:


SELECT COUNT(id) AS Total_Applications 
FROM bank_loan_data


--MTD Loan Applications (Current Month):


SELECT COUNT(id) AS Total_Applications 
FROM bank_loan_data 
WHERE MONTH(issue_date) = 12


--PMTD Loan Applications (Previous Month):


SELECT COUNT(id) AS Total_Applications 
FROM bank_loan_data 
WHERE MONTH(issue_date) = 11


--Total Funded Amount:

SELECT SUM(loan_amount) AS Total_Funded_Amount
FROM bank_loan_data


--MTD Total Funded Amount:


SELECT SUM(loan_amount) AS Total_Funded_Amount 
FROM bank_loan_data 
WHERE MONTH(issue_date) = 12


--PMTD Total Funded Amount:


SELECT SUM(loan_amount) AS Total_Funded_Amount 
FROM bank_loan_data 
WHERE MONTH(issue_date) = 11


--Total Amount Received:


SELECT SUM(total_payment) AS Total_Amount_Collected 
FROM bank_loan_data


--MTD Total Amount Received:


SELECT SUM(total_payment) AS Total_Amount_Collected 
FROM bank_loan_data 
WHERE MONTH(issue_date) = 12


--PMTD Total Amount Received:


SELECT SUM(total_payment) AS Total_Amount_Collected 
FROM bank_loan_data 
WHERE MONTH(issue_date) = 11



--Problem Statement: We need to calculate the percentage of good loans (Fully Paid or Current), 
--as well as summarize the count, funded amount, and received amount for these good loans.


--Good Loan Percentage:


SELECT 
  ((COUNT(CASE WHEN loan_status = 'Fully Paid' 
	   OR 
	   loan_status = 'Current' THEN id END) * 100.0) / 
       COUNT(id)) AS Good_Loan_Percentage
FROM bank_loan_data;



--Good Loan Applications:


SELECT COUNT(id) AS Good_Loan_Applications 
FROM bank_loan_data 
WHERE loan_status = 'Fully Paid' OR loan_status = 'Current'


--Good Loan Funded Amount:


SELECT SUM(loan_amount) AS Good_Loan_Funded_amount 
FROM bank_loan_data 
WHERE loan_status = 'Fully Paid' OR loan_status = 'Current'


--Good Loan Amount Received:


SELECT SUM(total_payment) AS Good_Loan_amount_received 
FROM bank_loan_data 
WHERE loan_status = 'Fully Paid' OR loan_status = 'Current'


--Problem Statement: We need to calculate the percentage of bad loans (Charged Off) and summarize the count,
--funded amount, and received amount for these bad loans.


--Bad Loan Percentage:


SELECT 
    (COUNT(CASE WHEN loan_status = 'Charged Off' THEN id END) * 100.0) / 
    COUNT(id) AS Bad_Loan_Percentage
FROM bank_loan_data


--Bad Loan Applications:


SELECT COUNT(id) AS Bad_Loan_Applications 
FROM bank_loan_data 
WHERE loan_status = 'Charged Off'


--Bad Loan Funded Amount:


SELECT SUM(loan_amount) AS Bad_Loan_Funded_amount 
FROM bank_loan_data 
WHERE loan_status = 'Charged Off'


--Bad Loan Amount Received:


SELECT SUM(total_payment) AS Bad_Loan_amount_received 
FROM bank_loan_data 
WHERE loan_status = 'Charged Off'


--Problem Statement: We need to analyze the loan data by status, including total loan count,
--total funded amount, total payments received, interest rates, and DTI.


SELECT
    loan_status,
    COUNT(id) AS LoanCount,
    SUM(total_payment) AS Total_Amount_Received,
    SUM(loan_amount) AS Total_Funded_Amount,
    AVG(int_rate * 100) AS Interest_Rate,
    AVG(dti * 100) AS DTI
FROM
    bank_loan_data
GROUP BY
    loan_status


--Problem Statement: We need to get monthly statistics on the total number of loan applications, 
--funded amounts, and payments received.


SELECT 
    MONTH(issue_date) AS Month_Munber, 
    DATENAME(MONTH, issue_date) AS Month_name, 
    COUNT(id) AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY MONTH(issue_date), DATENAME(MONTH, issue_date)
ORDER BY MONTH(issue_date)


--Problem Statement: We need to analyze loan applications by state,
--showing the total loan applications, funded amounts, and received payments for each state.


SELECT 
    address_state AS State, 
    COUNT(id) AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY address_state
ORDER BY address_state


--Problem Statement: We need to analyze loan applications based on their terms (e.g., 36 months, 60 months) 
--and see the total number of applications, funded amounts, and received payments.


SELECT 
    term AS Term, 
    COUNT(id) AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY term
ORDER BY term


--Problem Statement: We need to analyze loan applications by purpose (e.g., home improvement, debt consolidation) 
--and see the total number of applications, funded amounts, and received payments for each purpose.


SELECT 
    purpose AS Purpose, 
    COUNT(id) AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY purpose
ORDER BY purpose


--Problem Statement: We need to evaluate loan applications based on home ownership status (e.g., Homeowner, Rent)
--and summarize the total number of applications, funded amounts, and payments received.


SELECT 
    home_ownership AS Home_Ownership, 
    COUNT(id) AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
GROUP BY home_ownership
ORDER BY home_ownership


--Problem Statement: We need to apply filters to narrow down the loan data 
--and see how results change with specific conditions (e.g., loans with Grade A status).


SELECT 
    purpose AS Purpose, 
    COUNT(id) AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Amount_Received
FROM bank_loan_data
WHERE grade = 'A'
GROUP BY purpose
ORDER BY purpose